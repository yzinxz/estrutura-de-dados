#include <iostream>
using namespace std;

int contarOcorrencias(int itens[], int quantidade, int procurado) {
    if (quantidade == 0) {
        return 0;
    }

    if (itens[quantidade - 1] == procurado) {
        return 1 + contarOcorrencias(itens, quantidade - 1, procurado);
    }

    return contarOcorrencias(itens, quantidade - 1, procurado);
}

int main() {
    int itens[8] = {3, 7, 3, 1, 3, 9, 7, 3};

    cout << contarOcorrencias(itens, 8, 3) << endl;

    return 0;
}
