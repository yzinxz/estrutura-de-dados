#include <iostream>
#include <string>
#include <set>
#include <unordered_set>
using namespace std;

int main() {
	
	// 1
    set<string> cidades;

    cidades.insert("Sao Paulo");
    cidades.insert("Recife");
    cidades.insert("Curitiba");
    cidades.insert("Brasilia");
    cidades.insert("Salvador");
	
	// 2
    cout << "Usando set:" << endl;

    for (string cidade : cidades) {
        cout << cidade << endl;
    }
	
	// 3
    cout << "\nTamanho antes de inserir Sao Paulo novamente: " << cidades.size() << endl;

    cidades.insert("Sao Paulo");

    cout << "Tamanho depois de inserir Sao Paulo novamente: " << cidades.size() << endl;

	// 4
    string cidadeBusca = "Recife";

    if (cidades.find(cidadeBusca) != cidades.end()) {
        cout << "\n" << cidadeBusca << " esta no conjunto." << endl;
    } else {
        cout << "\n" << cidadeBusca << " não esta no conjunto." << endl;
    }

	// 5
    unordered_set<string> cidadesUnordered;

    cidadesUnordered.insert("Sao Paulo");
    cidadesUnordered.insert("Recife");
    cidadesUnordered.insert("Curitiba");
    cidadesUnordered.insert("Brasilia");
    cidadesUnordered.insert("Salvador");

    cout << "\nUsando unordered_set:" << endl;

    for (string cidade : cidadesUnordered) {
        cout << cidade << endl;
    }

    return 0;
}
