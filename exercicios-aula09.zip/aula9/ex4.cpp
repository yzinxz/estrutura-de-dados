#include <iostream>
#include <string>
#include <unordered_map>
using namespace std;

int main() {
	
	// 1
    unordered_map<string, string> tabela;

    tabela["Brasil"] = "Brasilia";
    tabela["Argentina"] = "Buenos Aires";
    tabela["Franca"] = "Paris";
    tabela["Japao"] = "Toquio";
    tabela["Italia"] = "Roma";

	// 2
    string pais = "Brasil";

    auto encontrado = tabela.find(pais);

    if (encontrado != tabela.end()) {
        cout << "Capital do " << pais << ": "
             << encontrado->second << endl;
    } else {
        cout << "Pais nao encontrado." << endl;
    }

	// 3
    tabela.erase("Japao");

    if (tabela.count("Japao") == 0) {
        cout << "Japao foi removido." << endl;
    } else {
        cout << "Japao ainda esta na tabela." << endl;
    }
	
	// 4
    cout << "\nPaises restantes:" << endl;

    for (auto& p : tabela) {
        cout << p.first << " - " << p.second << endl;
    }

	// 5
    tabela["Brasil"] = "Brasilia";
    tabela["Brasil"] = "Rio de Janeiro";

    cout << "\nCapital do Brasil: " << tabela["Brasil"] << endl;

	//Resposta: A segunda atribuicao substitui o valor anterior
	
    return 0;
}

	
