#include <iostream>
#include <string>
#include <unordered_map>
using namespace std;

int main() {
	
	// 1 e 2
    unordered_multimap<string, float> notas;

    notas.insert({"Carol", 8.5});
    notas.insert({"Carol", 7.0});
    notas.insert({"Carol", 9.0});

    notas.insert({"Luan", 10.0});
    notas.insert({"Luan", 9.0});
    notas.insert({"Luan", 7.0});
    
    notas.insert({"Livia", 6.5});
    notas.insert({"Livia", 8.0});
    notas.insert({"Livia", 9.5});

	// 3
    cout << "Carol possui " << notas.count("Carol") << " notas." << endl;

	// 4
    cout << "\nNotas da Carol:" << endl;

    auto intervalo = notas.equal_range("Carol");

    for (auto it = intervalo.first; it != intervalo.second; ++it) {
        cout << it->second << endl;
    }
	
	// 5
	cout << "\nTamanho da tabela antes de remover a Carol: " << notas.size() << endl;
	
    notas.erase("Carol");

    cout << "\nTamanho da tabela depois de remover a Carol: " << notas.size() << endl;
    
    return 0;
}
