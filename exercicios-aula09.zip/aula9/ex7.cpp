#include <iostream>
#include <unordered_set>
using namespace std;

int main() {
	
	// 1
    unordered_multiset<int> notas = {7, 8, 7, 9, 6, 8, 7, 10, 6, 9};

	// 2
    cout << "Quantidade de alunos que tiraram 7: " << notas.count(7) << endl;

	// 3
	cout << "Tamanho total antes: " << notas.size() << endl;
	
    notas.insert(8);
    notas.insert(5);

    cout << "Tamanho total depois: " << notas.size() << endl;
	
	// 4
	cout << "Quantidade de notas 6 antes: " << notas.count(6) << endl;
	
    notas.erase(6);

    cout << "Quantidade de notas 6 depois: " << notas.count(6) << endl;

	// 5
    cout << "\nNotas restantes:" << endl;

    for (int nota : notas) {
        cout << nota << endl;
    }

    return 0;
}
