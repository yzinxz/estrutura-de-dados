#include <iostream>
#include <string>
#include <map>
#include <unordered_map>
using namespace std;

int main() {
	
	// 1
    map<string, float> alunos;

    alunos["Carol"] = 8.5;
    alunos["Luan"] = 9.0;
    alunos["Livia"] = 7.5;
    alunos["Leticia"] = 6.0;
    alunos["Karen"] = 10.0;

	// 2
    cout << "Usando map:" << endl;

    for (auto& aluno : alunos) {
        cout << aluno.first << " - " << aluno.second << endl;
    }

	// 3
    unordered_map<string, float> alunosUnordered;

    alunosUnordered["Carol"] = 8.5;
    alunosUnordered["Luan"] = 9.0;
    alunosUnordered["Livia"] = 7.5;
    alunosUnordered["Leticia"] = 6.0;
    alunosUnordered["Karen"] = 10.0;

    cout << "\nUsando unodered_map:" << endl;

    for (auto& aluno : alunosUnordered) {
        cout << aluno.first << " - " << aluno.second << endl;
    }

    //Resposta: O map exibe os alunos em ordem alfabetica pela chave, já o unordered_map não

    return 0;
}
