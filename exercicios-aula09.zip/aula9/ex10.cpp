#include <iostream>
#include <string>
#include <unordered_map>
#include <unordered_set>
using namespace std;

int main() {
	
	// 1
    unordered_map<string, float> notas;

    notas["Carol"] = 9.0;
    notas["Luan"] = 7.5;
    notas["Livia"] = 8.0;
    notas["Leticia"] = 6.5;
    notas["Karen"] = 10.0;

	// 2
    unordered_set<string> entregaram;

    entregaram.insert("Carol");
    entregaram.insert("Carlos");
    entregaram.insert("Fernanda");

	// 3
    unordered_multimap<string, string> disciplinas;

    disciplinas.insert({"Carol", "Matematica"});
    disciplinas.insert({"Carol", "Portugues"});

    disciplinas.insert({"Luan", "Historia"});
    disciplinas.insert({"Luan", "Matematica"});

    disciplinas.insert({"Livia", "Portugues"});
    disciplinas.insert({"Livia", "Geografia"});

    disciplinas.insert({"Leticia", "Historia"});
    disciplinas.insert({"Leticia", "Ingles"});

    disciplinas.insert({"Karen", "Portugues"});
    disciplinas.insert({"Karen", "Matematica"});
    disciplinas.insert({"Karen", "Geografia"});

	// 4
    for (auto& aluno : notas) {

        string nome = aluno.first;
        float nota = aluno.second;

        cout << "\nAluno: " << nome << endl;
        cout << "Nota: " << nota << endl;

        if (entregaram.count(nome) > 0) {
            cout << "Trabalho: Entregou" << endl;
        } else {
            cout << "Trabalho: Nao entregou" << endl;
        }

        cout << "Disciplinas: ";

        auto intervalo = disciplinas.equal_range(nome);

        for (auto it = intervalo.first; it != intervalo.second; ++it) {
            cout << it->second << " ";
        }

        cout << endl;
    }

	// Resposta:
    // unordered_map:Foi usado para relacionar cada aluno com sua nota(cada aluno possui uma chave unica e o acesso e rapido)
    // unordered_set:Foi usado para guardar os alunos que entregaram o trabalho(apenas verificar se o nome existe ou nao)
    // unordered_multimap: Foi usado porque um mesmo aluno pode possuir varias
    // disciplinas(a mesma chave pode aparecer varias vezes)

    return 0;
}
