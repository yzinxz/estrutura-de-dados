#include <iostream>
#include <unordered_set>
using namespace std;

int main() {
	
	// 1
    unordered_set<int> numeros = {10, 20, 30, 20, 10, 40};

    cout << "Tamanho do set: " << numeros.size() << endl;
	
	// 2
    cout << "\nTamanho do set antes: " << numeros.size() << endl;

    numeros.insert(50);
    numeros.insert(20);

    cout << "Tamanho do set depois: " << numeros.size() << endl;
	
	// 3
    if (numeros.count(30) > 0) {
        cout << "\nO valor 30 existe no set." << endl;
    } else {
        cout << "\nO valor 30 nao existe no set." << endl;
    }
	
	// 4
    numeros.erase(10);

    cout << "\nElementos restantes:" << endl;

    for (int numero : numeros) {
        cout << numero << endl;
    }

	// 5
    unordered_set<int> ingressosUsados;

    ingressosUsados.insert(1);
    ingressosUsados.insert(2);
    ingressosUsados.insert(3);

    int ingresso = 2;

    if (ingressosUsados.count(ingresso) > 0) {
        cout << "\nIngresso " << ingresso << " ja foi usado." << endl;
    } else {
        cout << "\nIngresso " << ingresso << " ainda nao foi usado." << endl;

        ingressosUsados.insert(ingresso);
    }

    return 0;
}
